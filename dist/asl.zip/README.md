# asl
'''
su
rurima
cd /data
mkdir -p asl/test
pull alpine:edge ./asl/test
run ./asl/test

cat /etc/os-release

'''
